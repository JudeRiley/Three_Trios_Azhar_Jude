package cs3500.view;

public interface BoardPanelListener {
  void positionSelected(int row, int col);
}
