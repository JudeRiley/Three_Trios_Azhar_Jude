package cs3500.view;

public interface HandPanelListener {
  void cardSelected(int cardIndex);
}
